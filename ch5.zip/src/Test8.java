
public class Test8 {
	//�ݩʹw�]��
	//�D�򥻫� �w�]�O null
	//��� 0
	//�B�I 0.0
	//�r�� �ťզr��
	//���L false
	
	public static void main(String[] args)//throws Exception
	{
		
		TestException myEx = 
				new TestException();
//		System.out.println("Start.....");
//		myEx.stringNotEmpty("");
//		System.out.println("End.....");
		

		System.out.println("Start.....");
		try {
			myEx.testNet(false);
		   System.out.println("End.....1");
		}catch(Exception ex) {
			System.out.println(ex);
		}
		
		System.out.println("End.....2");
		
	}

}
