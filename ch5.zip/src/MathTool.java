
public class MathTool {
    public static int gcd(int a,
    		int b) {
    	int r = 0;
    	while(b != 0) {
    		r = a % b;
    		a = b;
    		b = r;
    	}
    	return a;
    }
    //�D����
    public static int rightTriangle(int a,int b) {
    	double d1 =  
    			Math.pow(a, 2);
    	double d2 = 
    			Math.pow(b, 2);
    	double c =
    			Math.sqrt(d1 + d2);//�}�ڸ�
    	return (int)c;
    }
}
