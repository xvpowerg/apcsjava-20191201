public class Dog extends Animal {
	// Override �Ƽg
	public String getName() {
		return "Dog:"+name;
	}
	
}
