
public class Test3 {
	public static void main(String[] args) {
		Animal a1 = new Animal();
		a1.setHeight(90);
		a1.setName("BeBe");
		System.out.println(a1.getHeight());
		System.out.println(a1.getName());
		
		Dog dgo1 = new Dog();
		dgo1.setHeight(10);
		dgo1.setName("MoMo");
//		System.out.println(dgo1.getHegiht());
//		System.out.println(dgo1.getName());
		
		//Polymorphic �h��
		Animal a2 = dgo1;
		System.out.println(a2.getName());
		
	}
}
