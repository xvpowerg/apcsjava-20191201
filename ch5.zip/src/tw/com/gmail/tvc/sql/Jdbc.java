package tw.com.gmail.tvc.sql;

public class Jdbc {
	public void connection() {
		System.out.
		println("��Ʈw�s�u......");
	}
}
