package tw.com.gmail.tvc.sql;

public class Test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test5 t5 = new Test5();
		
		System.out.println(t5.publicValu1);
		System.out.println(t5.protectedValu1);
		System.out.println(t5.defaultValue);
		
		t5.testPublic();
		t5.testProtected();
		t5.testDefault();
	}

}
