package tw.com.gmail.tvc.sql;

public class Test5 {
	//public  �ۦPpackage �P ���Ppackage ���]�iŪ�g
			public String publicValu1 =
					"public";
			//protected  �ۦPpackage �P �~�ӫ�iŪ�g
			protected String protectedValu1 
				= "protected";
			//default �ۦPpackage �iŪ�g
			String defaultValue = "default";
			//private �ۦP���O�~�iŪ�g
			private String
				  privateValue = "value";
			
			public void testPublic() {
				System.out.println("testPublic...");
			}
			
			protected void testProtected() {
				System.out.println("testProtected...");
			}
			 void testDefault() {
				System.out.println("testDefault...");
			}
			 private void testPrivate() {
					System.out.println("testPrivate...");
				}


}
