package tw.com.gmail.tvc.sql;
import tw.com.gmail.howard.System;
public class Test4 {
	public static void main(String[] args) {
		System s = 
				new System();
	java.lang.System.
			out.println(s.getFileSystem());
		//�ۦPPackage ����import
		Jdbc jdbc = new Jdbc();
		jdbc.connection();
	}

}
