package tw.com.gmail.action;
import tw.com.gmail.tvc.sql.Test5;
public class Test7 extends Test5{
	
	public void readProtected() {
		this.protectedValu1 = "";	
		  testProtected();
	}
	
	public static void main(String[] args) {
		Test5 t5 = new Test5();
		t5.publicValu1 = "Ken";
		t5.testPublic();
	}

}
