package tw.com.gmail.howard;
import java.nio.file.FileSystems;
public class System {
	public String getFileSystem() {
		java.lang.System.out.
		println("getFileSystem......");
	return FileSystems.
			getDefault().
			toString();
	}
}
