
public class Test1 {

	public static void main(String[] args) {
		Student st1 = new Student();
		st1.name = "Ken";
		st1.setAge(10);
		System.out.
		println(st1.name+":"+st1.getAge());

	   Student st2 = new Student(18,"Join");
	   System.out.
	   println(st2.name+":"+st2.getAge());
	   
	}

}
