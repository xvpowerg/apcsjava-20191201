
public class HomeWork2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(
				MathTool.gcd(20, 14));//2
		System.out.println(MathTool.
				rightTriangle(3, 4));//5
	}
}
