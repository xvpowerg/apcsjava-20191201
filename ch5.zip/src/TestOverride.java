
public class TestOverride {
   public void testOver1() {
	   System.out.println("testOver1!!");
   }
}
