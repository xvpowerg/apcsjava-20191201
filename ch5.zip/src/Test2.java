
public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass1 myc1 = new MyClass1();
		System.out.println(myc1.getA()+
				":"+
				myc1.getB());
		
		MyClass1 myc2 = new MyClass1(20,30);
		System.out.println(myc2.getA()+
				":"+
				myc2.getB());
	}

}
