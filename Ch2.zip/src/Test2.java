
public class Test2 {
    public static void main(String[] args) {
    	byte b1 = 10;
    	int i2 = b1;
    	
    	int i3 = 129;
    	byte b2 = (byte)i3;
    	
    	System.out.println(b2);
    	
    	String st1 = "ABC";
    	System.out.println(1+5+st1);
    
    	 short a = 1, b =2;
   
    	short c = (short)(a + b);
    	
    	byte bx = (byte)257;
    	System.out.println(bx);
    	
    	System.out.println(30 + 5 <= 5 + 31);
    	System.out.println((30 + 5) <= (5 + 31));
    	
    }
}
