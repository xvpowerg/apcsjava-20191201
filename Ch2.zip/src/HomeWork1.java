
public class HomeWork1 {
    public static void main(String[] args) {
    	//�Ʊ榳�p���I
//    	float c = 25.6f;
//    	float f = 9 / 5 * c + 32;
//    	System.out.println(f);
    	
//    	long n =1;
//    	System.out.println(n << 32);
//    	System.out.println(n << 38);
//    	System.out.println(n << 49);
    	
    	java.util.Scanner scan =
    			new java.util.Scanner(System.in);
    	
    	System.out.println("�п�J���:");
    	int value = scan.nextInt();
    	String msg = value % 2 == 0 ? "����":"�_��"; 
    	System.out.println(msg);
    	
    }
}
