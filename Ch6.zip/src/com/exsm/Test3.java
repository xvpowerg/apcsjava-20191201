package com.exsm;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Test3 {
	public static void main(String[] args) {
		//�򥻫��A�ફ��
		Number n1 = new Integer(2);
		Number n2 = new Integer(2);
		System.out.println(n1.intValue() + 3);
		System.out.println(n1.equals(n2));
		n1 = new Float(2.5f);
		System.out.println(n1.floatValue());
		
		Calendar calendar = new GregorianCalendar();
		System.out.println(calendar.get(Calendar.YEAR));
		System.out.println(calendar.get(Calendar.MONTH)+1);
		System.out.println(calendar.get(Calendar.DATE));
		
		Car to = new Mazda(); 
		to.controlEngine();
	}
}
