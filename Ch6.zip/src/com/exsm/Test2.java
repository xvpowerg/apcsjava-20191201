package com.exsm;

public class Test2 {

	public static void main(String[] args) {
		//��H�����O���inew
		Animal a1 = 
				new Dog("LuLu",5,6);
		Animal a2 = 
				new Dog("LuLu",5,6);
		System.out.println(a1);
		System.out.println(a1.equals(a2));
	}

}
