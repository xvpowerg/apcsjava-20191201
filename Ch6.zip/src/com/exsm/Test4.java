package com.exsm;
import java.util.Arrays;
public class Test4 {

	public static void main(String[] args) {
		Bird b1 = new Bird("KuKu",1,2);
		Fly f1 = b1;
		f1.flying(5);
		//Fly.speedMax = 10;
	System.out.println(Fly.speedMax);
		// �i�ƧǤ��� Comparable
		String[] values = {"C","A","B"};
		Arrays.sort(values);
		for (String s : values) {
			System.out.println(s);
		}

	}

}
