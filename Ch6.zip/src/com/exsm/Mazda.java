package com.exsm;

public class Mazda extends Car {
	public  void controlEngine() {
		System.out.println("�b�۰ʤ�");
	}
}
