package com.exsm;

public abstract class Animal {
	private String name;
	private int age;
	private float height;
	 
	public Animal(String name,int age,float height) {
		this.name = name;
		this.age = age;
		this.height = height;
	}
	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public float getHeight() {
		return height;
	}
	
	public String toString() {
		return this.getName()+":"+
				this.getAge()+":"+
				this.getHeight();
	}
	public boolean equals(Object obj) {
		if (obj == null ||
				obj.getClass() != this.getClass()) {
			return false;
		}
		Animal tmp = (Animal)obj;
		return this.getName().equals(tmp.getName()) &&
				this.getAge() == tmp.getAge() &&
				this.getHeight() == tmp.getHeight();
		
	}
}
