package com.exsm;

public class Fruit {
	private String name;
	private int price;
	
	public Fruit(String name,
				int price) {
		this.name = name;
		this.price = price;
	}
	
	public String getName() {
		return name;
	}
	
	public int getPrice() {
		return price;
	}
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != Fruit.class ) {
			return false;
		}
		
		Fruit tmpFr = (Fruit)obj;
			
		return this.getName().
				equals(tmpFr.getName()) && 
				this.getPrice() 
				== tmpFr.getPrice();
		
	}
	
	public String toString() {
		return this.getName()+":"+this.getPrice();
	}
}
