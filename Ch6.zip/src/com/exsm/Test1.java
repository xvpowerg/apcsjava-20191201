package com.exsm;

public class Test1 {

	public static void main(String[] args) {
		
		Fruit fr1 = 
			new Fruit("Apple",50);
		Fruit fr2 = 
				new Fruit("Apple",50);
	
	
		System.out.println(fr1);
		System.out.println(fr2);
		
		System.out.println(
				fr1.equals(fr2));
		
		System.out.println(
				fr1.equals(null));
		Test1 t1 = new Test1();
		System.out.println(
				fr1.equals(t1));
		
	}

}
