package com.exsm;

public class Toyota extends Car {
	public  void controlEngine() {
		System.out.println("AI");
	}
}
