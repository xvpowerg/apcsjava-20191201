package com.exsm;

public class Bird extends Animal implements Fly{

	public Bird(String name, int age, float height) {
		super(name, age, height);
	}
	
	public void flying(int speed) {
		System.out.
		println("Bird:"+this.getName()+" Speed:"+speed);
	}

}
