package com.test.tools;

public class TestString6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			//�j��	
			String values = "ACBCA";
				values = values.toUpperCase();
				int i = 0,j = values.length()-1;
				boolean isTrue = true;
				while(i < j) {
					if (values.charAt(i++) != values.charAt(j--)) {
						isTrue=false;
						break;
					}
				}
				System.out.println(isTrue);	
	}

}
