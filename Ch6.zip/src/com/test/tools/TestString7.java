package com.test.tools;

public class TestString7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//�|���ܨӷ����r��
		StringBuffer sb = new StringBuffer("abc");
		System.out.println(sb);
		sb.append("EFG");
		System.out.println(sb);
		
		//�r������ �@�w�n�|!!!
		int v1 = Integer.parseInt("20");
		int v2 = Integer.parseInt("12");
		System.out.println(v1+v2);
		
		
	}

}
