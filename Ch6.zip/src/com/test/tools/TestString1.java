package com.test.tools;

public class TestString1 {

	public static void main(String[] args) {
		//�إߦr�ꪺ�覡
//		String st1 = new String("Ken");
//		String st2 = "Vivin";
//		String float1 = String.valueOf(2.5f);
//		System.out.println(st1+":"+st2+":"+float1);
		//�r�ꪺ���
		//����O�_�۵�
		String n1 = "Ken";
		
		String n2 = "Ken";
		System.out.println(n1 == n2);
		
		String n3 = String.valueOf("Ken");
		System.out.println(n1 == n3);
		
		String n4 = new String("Ken");
		System.out.println(n1 == n4);
		
		System.out.println(n1.equals(n4) );
		
	}

}
