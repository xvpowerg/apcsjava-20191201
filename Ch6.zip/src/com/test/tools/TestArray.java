package com.test.tools;

public class TestArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] scores = new int[5];
		scores[0] = 71;
		scores[1] = 92;
		scores[2] = 83;
		scores[3] = 65;
		scores[4] = 41;
		//�i��l�ȫŧi
		String[] name = {"Ken","Vivin","Join","Lindy","Tom"};		
		for (int i = 0; i < scores.length;i++) {
			int s = scores[i];
			System.out.println(s);
		}
		
//		for (int i = 0; i < name.length;i++) {
//			String n = name[i];
//			System.out.println(n);
//		}
		for (String n : name) {
			System.out.println(n);
		}
		
	}

}
