package com.test.tools;
import java.util.ArrayList;
public class TestArray3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add("Ken");
		list.add("Vivin");
		list.add("Join");
		
		for (int i = 0; i <list.size();i++) {
			System.out.println(list.get(i));
		}
	}

}
