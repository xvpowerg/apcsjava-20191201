package com.test.tools;

public class TestArray2 {

	public static void main(String[] args) {
			
		int[][] array2x3 = new int [2][3];
		array2x3[0][0] = 71;
		array2x3[1][0] = 83;
		array2x3[1][2] = 95;
		//2
		for (int i = 0; i <array2x3.length ;i++) {
			//3
			for (int k = 0; k <array2x3[i].length ;k++) {
				System.out.print(array2x3[i][k]+" ");
			}
			System.out.println();
		}
	}

}
