package com.test.tools;

public class TestString4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String str1 = " ABCDEFG ";
			System.out.println(str1);
			//trim() �h�����k�Ů�
			System.out.println(str1.trim());
			String str2 = "Ken";
			System.out.println(str2.length());
			
			String str3 = "Howard";
			for (int i= 0; i< str3.length();i++) {
				System.out.println(str3.charAt(i));
			}
			
			
			String str4 = "ABCDEFG";
			String str5 = str4.substring(2);
			System.out.println(str5);
			//�]�t2  �p�� 5
			String str6 =  str4.substring(2,5);
			System.out.println(str6);
			
			
			
	}

}
