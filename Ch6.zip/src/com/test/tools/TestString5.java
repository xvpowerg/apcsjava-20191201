package com.test.tools;

public class TestString5 {

	public static void main(String[] args) {
//		String str = "Howard Ken Vivin Join";
//		String[] strArray = str.split(" ");
//		for (String n : strArray) {
//			System.out.println(n);
//		}
		
		String values = String.format("�m�W:%s �~��:%.2f", "Ken",12.56f);
		System.out.println(values);

	}

}
