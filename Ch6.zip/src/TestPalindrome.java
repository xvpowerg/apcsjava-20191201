
public class TestPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String st = "A";
	st = st.toUpperCase();
			int i = 0, j = st.length() - 1;
			boolean isPalinderome = true;
		while(i < j) {
			if (st.charAt(i++) != st.charAt(j--)) {
				isPalinderome = false;
				break;
			}
		}
		System.out.println(isPalinderome);
	
	}

}
