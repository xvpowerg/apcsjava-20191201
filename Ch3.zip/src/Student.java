
public class Student {
	  String name;
	  int age;
	 void setName(String inName,int maxLen) {
		name = inName;
	}
	 String getName() {
		return name;
	}
	 
	 int getAge() {
		 return age;
	 }
	
}
