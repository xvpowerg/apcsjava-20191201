
public class Ch3_8 {

	public static void main(String[] args) {
		
		Tag1:
		for (int i =1;i<=5;i++) {
			Tag2:
			for(int k =1; k<=7;k++) {
				if (i == 3) {
					break Tag1; //���}�j��
					 //continue Tag1; //�h�U���j��
					}
			System.out.print(i+":"+k+" ");
				
			}
			System.out.println();
			
		}

	}

}
