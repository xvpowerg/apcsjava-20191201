
public class MyCount {
    int x;
    
   void printX() {
	   System.out.print(x);
   }
}
