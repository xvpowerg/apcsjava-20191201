
public class Value {
		public int i;
}
