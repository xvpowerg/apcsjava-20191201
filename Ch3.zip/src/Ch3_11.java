
public class Ch3_11 {

	
	static void test1(int i) {
		if (i <= 3) {
			System.out.println(i);
			test1(i+1);
		}
		 System.out.println(i);
	}
	
	public static void main(String[] args) {
		test1(1);
	}

}
