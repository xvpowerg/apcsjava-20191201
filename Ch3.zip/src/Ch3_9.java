
public class Ch3_9 {

	 static void testCallByValue(int y) {
			y++;
	 }
	 
	 static void testCallByReference(MyCount myc) {
		   myc.x++;
      }
	
	
	public static void main(String[] args) {
		 
//		int y =0;
//		testCallByValue(y);
//		System.out.println(y);
		
		MyCount myc = new MyCount();
		testCallByReference(myc);
		myc.printX();

	}

}
