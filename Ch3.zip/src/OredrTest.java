
public class OredrTest {

	public static void main(String[] args) {
	  Shirt s1 = new Shirt();
	  Shirt s2 = new Shirt();
	  Shirt s3 = new Shirt();	
	  s1.price = 14.99f;
	  s2.price = 23.55f;
	  s3.price = 49.99f;
	  Order orderObj = new Order(); 
	  orderObj.addShirt(s1);
	  orderObj.addShirt(s2);
	  orderObj.addShirt(s3);
	  
	  System.out.printf("sum:%.2f",  
			  orderObj.sum()) ;
	}

}
