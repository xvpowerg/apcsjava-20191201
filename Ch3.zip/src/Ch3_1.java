
public class Ch3_1 {

	public static void main(String[] args) {
		int a =0,i = 1,j=-1,k=2;
		if (i > 0) { 
			 if(j > 0) { 
			     if(k > 0) a =100;  
			 }else {
				 a = 200; 
			 }
		}else { 
		   a=300;
		}
		
		
	
		System.out.println(a);

	}

}
