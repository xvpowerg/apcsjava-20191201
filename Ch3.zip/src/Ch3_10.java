
public class Ch3_10 {
    public static void main(String[] args) {
    	Value v = new Value();
    	v.i = 10;
    }
}
