
public class Ch3_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int play =1;		
		switch(play) {
		   case play:
			   System.out.println("Play");			   
		   case 2:
			   System.out.println("Stop");
		}
		
		char v = 'A';
		System.out.println((int)v);
		
	}

}
