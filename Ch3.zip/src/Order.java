
public class Order {
	Shirt[] myShirts = new Shirt[3];
	int index = 0;
    void addShirt(Shirt s) {
    	myShirts[index++] = s;
    }
    
    float sum() {
    	float values = 0;
    	for (int  i =0;
    			i<myShirts.length ;i++) {
    		values += myShirts[i].price;
    	}
    	return values;
    }
}
