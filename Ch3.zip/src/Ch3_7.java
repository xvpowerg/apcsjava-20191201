
public class Ch3_7 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner scan =
				new java.util.Scanner(System.in);
		int h =4,w = 3;		
		System.out.println("�п�J��:");
		h = scan.nextInt();
		System.out.println("�п�J�e:");
		w = scan.nextInt();
	  for (int k =1; k<=w; k++) {
		  	for (int i =1;i<=h;i++) {
			System.out.print("@");
		   }
		    System.out.println();
	  }		
	}
}
