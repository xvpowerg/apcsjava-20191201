
public class Skill {

}
