
public class Ch3_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner scan =
				new java.util.Scanner(System.in);
		String v  = scan.next();
		System.out.println(v);
		
	}

}
