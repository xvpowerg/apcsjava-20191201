
public class Shirt {
	float price;
}
