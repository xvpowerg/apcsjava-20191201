package test1;
import static test1.TestStatic.showMessage;
public class Test6 {

public static
	void main(String[] args) {
		// TODO Auto-generated method stub
		showMessage();
	}

}
