package test1;

public class TestStatic {
       public static void showMessage(){
    	   System.out.println("showMessage "
    	   		+ "TestStatic!!");
       }
}
