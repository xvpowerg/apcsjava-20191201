
public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Animal an1 = new Animal();
			an1.setName("Howard");
			an1.setAge(91);
			//an1.setStaticValue("Apple");
			Animal.setStaticValue("Apple");
		
			System.out.
			println(an1.getName());
			System.out.
			println(an1.getAge());
			
			Animal an2 = new Animal();
			//an2.setStaticValue("Charry");
			Animal.setStaticValue("Charry");
			//name ken
			//age 83'
			an2.setName("Ken");
			an2.setAge(83);
			System.out.println(an2.getName());
			System.out.println(an2.getAge());
//			System.out.println(
//					an2.getStaticValue());
			System.out.println(
					Animal.getStaticValue());
			
			System.out.
			println(an1.getName());
			System.out.
			println(an1.getAge());
			System.out.
			println(
				an1.getStaticValue());
			
	}

}
