
public class Test2 {

	//�i�H�ǤJn���Ѽ� vargs
	static void testVargs(int... values) {
		int sum = 0;
		for (int x : values) {
			sum += x;
		}
		System.out.println(sum);
		
	}
	
	static int testMax(int... values) {
		int max =-2147483648;
		for (int v : values) {
			if (v > max) {
				max = v;
			}
		}
		return max;
	}
	
	public static void main(String[] args) {
		
		testVargs();
		testVargs(1,5);
		testVargs(1,6,7,8);
	System.out.println(testMax(5,1,7,9,3));
	}

}
