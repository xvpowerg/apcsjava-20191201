
public class Animal {
	 String name;
	 int age;
	static String staticValue;
	static void setStaticValue(String value) {
		staticValue = value;
	}
	static String getStaticValue() {
		return staticValue;
	}
	
	public void setName(String myName) {
		name = myName  ;
	}
	public String getName() {
		return name;
	}
	public void setAge(int myAge) {
		age = myAge;
	}
	public int getAge() {
		return age;
	}
}
