
public class HomeWork2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//n �����p��26
		int h = 8;
		char showMsg = 'A';
				for (int i = 1,count=1;i <= h;i++,count+=2,
						showMsg++) {
					
					for (int space =h - i ;space >0;space--) {
						System.out.print(" ");
					}
					
					for (int letter=1 ;letter <= count;letter++) {
						System.out.print(showMsg);
					}
					System.out.println();
				}
	}

}
