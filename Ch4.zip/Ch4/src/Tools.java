
public class Tools {
    public static String toUpper(String value) {
    	return value.toUpperCase();
    }
}
