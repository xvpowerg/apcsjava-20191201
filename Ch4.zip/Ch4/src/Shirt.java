
public class Shirt {
    public static int counter = 0;
    static String shirtVersion;
    public int shirtID;
    int size;
    
    static {
    	java.util.Random ran  = new java.util.Random();
    	shirtVersion = 
    			ran.nextInt(5000)+"";
    }
    
    public static void printVersion() {
    	System.out.println(
    			shirtVersion);
    }
    
    public Shirt() {
    	counter++;
    	shirtID = counter;
    }
    
    public Shirt(int size) {
    	//this ���ܥثe����
    	this.size = size;
    }
    public String getType() {
    	
    		return convertSizeToType(size);
    }		
    
    public static String convertSizeToType(int size) {
    			//System.out.println(shirtID);
    			switch(size) {
    			case 37:
    				return "S" ;
    			case 38:
    				return "M" ;		
    			case 39:
    				return "L" ;	
    			}
    	return "XL";
    }
    
    public static int getTotalCuunt() {
    	return counter;
    }
}
