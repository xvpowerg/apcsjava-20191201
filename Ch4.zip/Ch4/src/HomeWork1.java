import java.util.Scanner;
public class HomeWork1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);	
		System.out.println("�п�J�P���X");
		String day = scan.next();
		
		switch(day) {
			case "Mon":
				System.out.println("���^��");
				break;
			case "Tue":
				System.out.println("��ѽ�");
				break;	
			case "Wed":
				System.out.println("�^���");
				break;
			case "Thu":
				System.out.println("��y��");
				break;		
			case "Fri":
				System.out.println("�`����");
				break;
			case "Sat":
				System.out.println("�q����");
				break;	
			case "Sun":
				System.out.println("�@���");
				break;		
		}
	}

}
