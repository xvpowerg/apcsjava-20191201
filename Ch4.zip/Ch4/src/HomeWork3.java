
public class HomeWork3 {
	public static void main(String[] args) {
		int n = 11;
		int test = n;
		boolean isPrimeNumber = true ;
		while(--n > 1) {
			if (test % n == 0) {
				isPrimeNumber = false;
				break;
			}
		}
		
		System.out.println(isPrimeNumber?"���":"���O���");
		
		
	}

}
