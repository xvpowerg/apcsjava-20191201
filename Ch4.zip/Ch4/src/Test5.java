
public class Test5 {
	public static void main(String[] args) {
		Shirt s1 = new Shirt();
		System.out.println(Shirt.getTotalCuunt());
		Shirt s2 = new Shirt();
		System.out.println(Shirt.getTotalCuunt());
		
		Shirt s3 = new Shirt(40);
		System.out.println(s3.getType());
		
		Shirt.printVersion();
		Shirt.printVersion();
		Shirt.printVersion();
		
	}
}
